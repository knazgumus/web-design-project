using Microsoft.AspNetCore.Identity;

namespace project1.Models
{
    public class Users: IdentityUser
    {
        public string? FullName {get; set;} 
    }
}