using Microsoft.EntityFrameworkCore;
using project1.Models;

namespace project1.Data{
    public class ImageDbContext : DbContext
    {   
        public DbSet<Image> Images {get; set;}
        public ImageDbContext(DbContextOptions<ImageDbContext> options) : base(options)
        {
        }
        
        
    }

}