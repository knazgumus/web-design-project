using Microsoft.AspNetCore.Mvc;
using project1.Data;
using project1.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using System.IO;
using System.Linq;

namespace project1.Controllers
{
    public class PicterestController : Controller
    {
        private readonly ImageDbContext _context;

        public PicterestController(ImageDbContext context)
        {
            _context = context;
        }

        [Authorize]
        public IActionResult Main()
        {
            var images = _context.Images.ToList();
            return View(images);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(IFormFile file, string caption)
        {
            if (file != null && file.Length > 0 && !string.IsNullOrEmpty(caption))
            {
                var filePath = Path.Combine("wwwroot/upload", file.FileName);
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    file.CopyTo(stream);
                }

                var image = new Image
                {
                    FileName = file.FileName,
                    Caption = caption
                };
                _context.Images.Add(image);
                _context.SaveChanges();
                return RedirectToAction("Main", "Picterest");
            }
            return View();
        }

        public IActionResult Edit(int id)
        {
            var image = _context.Images.Find(id);
            if (image == null)
                return NotFound();

            return View(image);
        }

        [HttpPost]
        public IActionResult Edit(int id, string caption)
        {
            var image = _context.Images.Find(id);
            if (image == null)
                return NotFound();

            image.Caption = caption;
            _context.SaveChanges();
            return RedirectToAction("Main", "Picterest");
        }

        public IActionResult Delete(int id)
        {
            var image = _context.Images.Find(id);
            if (image == null)
                return NotFound();

            return View(image);
        }

        [HttpPost] 
        [ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            var image = _context.Images.Find(id);
            if (image != null)
            {
                var filePath = Path.Combine("wwwroot/upload", image.FileName);
                if (System.IO.File.Exists(filePath))
                {
                    System.IO.File.Delete(filePath);
                }
                _context.Images.Remove(image);
                _context.SaveChanges();
            }
            return RedirectToAction("Main", "Picterest");
        }
    }
}
